#include<bits/stdc++.h>
using namespace std;
void code(){
    int n,tm=0;
    cin>>n;
    int x=(n/10)*25;
    n-=(n/10)*10;
    x+=(n/8)*20;
    n

}