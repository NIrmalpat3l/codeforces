// Accepted
# include<bits/stdc++.h>
using namespace std;
int main(){
    int t,s;
    cin>>t;
    while(t--){
        cin>>s;
        if(s>26){
            cout<<"No";
        }
        else{
            cout<<"Yes";
        }
        cout<<endl;
    }
    return 0;
}