#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin>>n;
    int a[3];
    cin>>a[0]>>a[1]>>a[2];
    sort(a,a+n);
    int f=n/a[0];
    if((n-(f*n))<)
}