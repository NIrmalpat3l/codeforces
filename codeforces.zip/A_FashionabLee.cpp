// Accepted
#include<bits/stdc++.h>
using namespace std;
void code(){
    int n;
    cin>>n;
    if(n%4==0){
        cout<<"YES";
    }else{
        cout<<"NO";
    }
}
int main()
{
    int t;
    cin>>t;
    while(t--){
        code();
        cout<<endl;
    }
}
