// Accepted
#include<bits/stdc++.h>
using namespace std;
void code(){
    int a,b,c,d;
    cin>>a>>b>>c>>d;
    cout<<b<<" "<<c<<" "<<c;
}
int main(){
    int t;
    cin>>t;
    while(t--){
        code();
        cout<<endl;
    }
    return 0;
}