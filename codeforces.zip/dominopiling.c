#include<stdio.h>
int main()
{
    int a,b,c;
    scanf("%d %d",&a,&b);
    c=(int) a*b/2;
    printf("%d",c);
}