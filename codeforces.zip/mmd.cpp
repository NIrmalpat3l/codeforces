#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin>>n;
    if(n%2==0) cout<<"Mahmoud";
    else cout<<"Ehab";
    return 0;
} 