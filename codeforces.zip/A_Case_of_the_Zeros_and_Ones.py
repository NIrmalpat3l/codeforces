# Accepted
n = int(input())
s = input()
print(abs(s.count('1')-s.count('0')))