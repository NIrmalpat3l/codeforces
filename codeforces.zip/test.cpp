
#include<bits/stdc++.h>
using namespace std;
int main(){
    int c;
    c=2^3;
    cout<<c;
    return 0;
}