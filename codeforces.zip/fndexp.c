#include<stdio.h>
int main()
{
    int n,i,j,a;
    scanf("%d",&n);
    for(a=1;a<=n;a++)
    {
        scanf("%d",&)
    }
}