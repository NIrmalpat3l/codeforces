#include<stdio.h>
#include<string.h>
void main(){
    char str[100];
    printf("Enter any string:");
    scanf("%s",&str);
    char ch;
    scanf("%c",&ch);
    printf("%c",&ch);
    // for(int i=0;i<strlen(str);i++){
    //     if(str[i]!=ch){
    //         printf("%c",str[i]);
    //     }
    // }
}
