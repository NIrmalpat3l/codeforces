// Accepted
#include<bits/stdc++.h>
using namespace std;
void code(){
    long long int n,m,i,j;
    cin>>n>>m>>i>>j;
    cout<<"1 1 "<<n<<" "<<m;
}
int main(){
    int t;
    cin>>t;
    while(t--){
        code();
        cout<<endl;
    }
}