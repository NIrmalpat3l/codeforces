#include<bits/stdc++.h>
using namespace std;
int main(){
    int n,m,c;
    cin>>n>>m;
    int x=n;
}