#include<bits/stdc++.h>
using namespace std;
int main(){
    int x;
    cin>>x;
    if(x==2)  cout<<"NO";
    else if(x%2==0) cout<<"YES";
    else cout<<"NO";
    return 0;
}