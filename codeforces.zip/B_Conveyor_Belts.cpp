#include<bits/stdc++.h>
using namespace std;
void code(){
    int n,x,y,a,b;
    cin>>n>>x>>y>>a>>b>>c;
}