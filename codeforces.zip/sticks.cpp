
#include<bits/stdc++.h>
using namespace std;
int main(){
  long long n,t;
  cin>>t;
  while(t--){
    cin>>n;
    if(n%2) cout<<(n/2)+1;
    else cout<<n/2;
    cout<<endl;
  }
  return 0;
}