#include<bits/stdc++.h>
using namespace std;
int main(){
    int t;
    cin>>t;
    while(t--){
        int a,b;
        char c;
        cin>>a>>c>>b;
        cout<<a+b;
        cout<<endl;
    }
    return 0;
}