#include<bits/stdc++.h>
using namespace std;
int main(){
    cout<<"25";
    return 0;
}

