#include <bits/stdc++.h>
using namespace std;
int main(){
    int t;
    cin>>t;
    while(t--){
        long long int n;
        cin >> n;
        cout<<n/2<<endl;
    }
    return 0;
}